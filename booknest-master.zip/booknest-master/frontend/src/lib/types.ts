export interface Book {
  id: string;
  title: string;
  author: string;
  price: number;
  format: string;
  category: string;
  rating: number;
  reviews_count: number;
  pages: number;
  year: number;
  isbn: string;
  cover_url: string;
  description: string;
  quote: string;
}

export interface CartItem {
  book: Book;
  quantity: number;
}

export interface OrderItem {
  book_id: string;
  title: string;
  quantity: number;
  unit_price: number;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  shipping_address: string;
  items: OrderItem[];
  total: number;
  status: string;
  demo_mode: boolean;
  delivery_estimate: string;
  created_at: string;
}
