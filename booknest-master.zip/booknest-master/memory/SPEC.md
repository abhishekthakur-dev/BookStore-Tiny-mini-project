# BookNest Living Spec

## Purpose
BookNest is a simple warm-editorial online bookstore for discovering curated books and completing a clearly labeled demo purchase.

## Data model
- `Book`: seeded catalog item with title, author, price, format, category, rating, review count, pages, year, ISBN, cover, description, and quote.
- `Order`: demo order with customer details, server-priced line items, total, confirmation number, delivery estimate, and `demo_mode: true`.

## Key flows
1. Browse the seeded catalog, search by title/author/description, filter by category, and sort by title or price.
2. Open a book detail view, choose a quantity, and add the book to the local cart.
3. Review the cart, adjust quantities, and open Demo Bookstore Checkout.
4. Prefill the demo form or enter name/email/address, submit, and view a vintage receipt confirmation.

## Auth and integrations
No authentication. No real payment provider or external integration; checkout is explicitly demo-only.