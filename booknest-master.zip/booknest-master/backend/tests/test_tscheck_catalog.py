import re


def test_catalog_is_seeded_and_detail_is_available(client):
    response = client.get('/books')
    assert response.status_code == 200, response.text[:300]
    books = response.json()
    assert len(books) >= 8
    titles = {book['title'] for book in books}
    assert 'The Architecture of Silence' in titles
    book_id = next(book['id'] for book in books if book['title'] == 'The Architecture of Silence')
    detail = client.get(f'/books/{book_id}')
    assert detail.status_code == 200, detail.text[:300]
    payload = detail.json()
    assert payload['id'] == book_id and payload['description'] and payload['price'] > 0


def test_missing_book_is_rejected(client):
    response = client.get('/books/tscheck-missing-book')
    assert response.status_code == 404
