def test_demo_order_is_created_from_seeded_book(client):
    response = client.post('/orders', json={
        'customer_name': 'tscheck Reader',
        'customer_email': 'tscheck@example.com',
        'shipping_address': '14 tscheck Lane, Portland, OR',
        'items': [{'book_id': 'book-1', 'quantity': 2}],
    })
    assert response.status_code == 200, response.text[:300]
    order = response.json()
    assert order['order_number'].startswith('BN-')
    assert order['demo_mode'] is True
    assert order['total'] == 57.0
    assert order['items'][0]['title'] == 'The Architecture of Silence'
    assert order['delivery_estimate']


def test_order_rejects_unknown_book(client):
    response = client.post('/orders', json={
        'customer_name': 'tscheck Reader',
        'customer_email': 'tscheck@example.com',
        'shipping_address': '14 tscheck Lane, Portland, OR',
        'items': [{'book_id': 'tscheck-unknown-book', 'quantity': 1}],
    })
    assert response.status_code == 400
