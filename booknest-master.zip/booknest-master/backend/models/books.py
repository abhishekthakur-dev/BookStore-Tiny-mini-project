from pydantic import BaseModel, Field


class Book(BaseModel):
    id: str
    title: str
    author: str
    price: float = Field(gt=0)
    format: str
    category: str
    rating: float = Field(ge=0, le=5)
    reviews_count: int = Field(ge=0)
    pages: int = Field(gt=0)
    year: int
    isbn: str
    cover_url: str
    description: str
    quote: str
