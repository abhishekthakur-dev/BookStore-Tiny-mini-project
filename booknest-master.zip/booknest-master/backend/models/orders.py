from datetime import datetime
from pydantic import BaseModel, Field


class OrderItemCreate(BaseModel):
    book_id: str
    quantity: int = Field(gt=0, le=20)


class OrderCreate(BaseModel):
    customer_name: str = Field(min_length=2, max_length=100)
    customer_email: str = Field(min_length=5, max_length=200)
    shipping_address: str = Field(min_length=5, max_length=300)
    items: list[OrderItemCreate] = Field(min_length=1, max_length=30)


class OrderItem(BaseModel):
    book_id: str
    title: str
    quantity: int
    unit_price: float


class Order(BaseModel):
    id: str
    order_number: str
    customer_name: str
    customer_email: str
    shipping_address: str
    items: list[OrderItem]
    total: float
    status: str
    demo_mode: bool
    delivery_estimate: str
    created_at: datetime
