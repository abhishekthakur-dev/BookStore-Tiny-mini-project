from fastapi import APIRouter, HTTPException

from lib.db import db
from models.books import Book

router = APIRouter(prefix="/books", tags=["books"])


@router.get("", response_model=list[Book])
async def list_books() -> list[Book]:
    documents = await db.books.find().sort("title", 1).to_list(100)
    return [Book(**document) for document in documents]


@router.get("/{book_id}", response_model=Book)
async def get_book(book_id: str) -> Book:
    document = await db.books.find_one({"id": book_id})
    if not document:
        raise HTTPException(status_code=404, detail="Book not found")
    return Book(**document)
