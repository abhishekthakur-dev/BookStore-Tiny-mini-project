from datetime import datetime, timezone
import uuid

from fastapi import APIRouter, HTTPException

from lib.db import db
from models.orders import Order, OrderCreate, OrderItem

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("", response_model=Order)
async def create_order(input: OrderCreate) -> Order:
    book_ids = [item.book_id for item in input.items]
    books = await db.books.find({"id": {"$in": book_ids}}).to_list(100)
    books_by_id = {book["id"]: book for book in books}
    if len(books_by_id) != len(set(book_ids)):
        raise HTTPException(status_code=400, detail="One or more books are unavailable")

    items = [
        OrderItem(
            book_id=item.book_id,
            title=books_by_id[item.book_id]["title"],
            quantity=item.quantity,
            unit_price=books_by_id[item.book_id]["price"],
        )
        for item in input.items
    ]
    total = round(sum(item.quantity * item.unit_price for item in items), 2)
    now = datetime.now(timezone.utc)
    order = Order(
        id=str(uuid.uuid4()),
        order_number=f"BN-{uuid.uuid4().hex[:6].upper()}",
        customer_name=input.customer_name,
        customer_email=input.customer_email,
        shipping_address=input.shipping_address,
        items=items,
        total=total,
        status="confirmed",
        demo_mode=True,
        delivery_estimate="Arrives in 3–5 reading days",
        created_at=now,
    )
    await db.orders.insert_one(order.model_dump())
    return order
